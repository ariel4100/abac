<!-- Materialize Core CSS -->
<link href="{{ asset('css/materialize.min.css') }}" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="{{ asset('css/admin.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/estilo.css')}}">

<!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<link rel="shortcut icon" href="{{ asset('img/contenido/'.$favicon->image) }}" type="image/png">
<link rel="icon" href="{{ asset('img/contenido/'.$favicon->image) }}" type="image/png">
