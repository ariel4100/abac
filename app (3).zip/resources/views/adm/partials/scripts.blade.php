<!-- jQuery -->
<script src="{{ asset('js/jquery.min.js')}}"></script>

<!-- Materialize Core JavaScript -->
<script src="{{ asset('js/materialize.min.js')}}"></script>

<!-- Core JS -->
<script src="{{ asset('js/admin.js')}}"></script>
@stack('scripts')
