
@include('adm.partials.scripts')
</body>
</html>