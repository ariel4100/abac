@extends('layouts.app')

@section('content')
    <div class="container">
        @include('templates.error')
        @include('page.partials.title', ['title' =>  __('Login') ])
        <form action="{{ route('login') }}" method="POST" class="row mb50">
            @csrf
            <div class="row mt20">
                <div class="input-field col s6">
                    <input id="username" name="username" type="text" class="validate" required>
                <label for="username">{{ __('Username') }}</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                    <input id="password" name="password" type="password" class="validate" required>
                    <label for="password">{{ __('Password') }}</label>
                </div>
            </div>
            <button class="btn waves-effect waves-light" type="submit" name="action" style="background-color: #E1131B;">{{ __('Login') }}
                <i class="material-icons right">send</i>
            </button>
        </form>
    </div>
@endsection
