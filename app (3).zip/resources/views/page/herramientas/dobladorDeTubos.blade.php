@extends('layouts.app')

@section('content')
<div class="container">
    @include('page.partials.title', ['title' => 'Cálculo de Doblado de Tubos'])
</div>
@endsection