

<?php $__env->startSection('body'); ?>
<main>
    <div class="row">
        <div class="input-field col s6 offset-s1 mt30">
        <select class="selector-product">
            <option value="" disabled selected>Elija una familia</option>
            <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($f->id); ?>"><?php echo e($f->{'title_'.App::getLocale()}); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label>Familias</label>
        </div>
    </div>

    <div class="row" style="margin-left:100px;">
        <a class="waves-effect waves-light btn gogo">Ver productos</a>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const selector = document.querySelector('.selector-product')
        const action = document.querySelector('.gogo')
        M.FormSelect.init(selector);

        selector.addEventListener('change', () => action.href = `/abac/adm/producto/${selector.value}/show`)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>