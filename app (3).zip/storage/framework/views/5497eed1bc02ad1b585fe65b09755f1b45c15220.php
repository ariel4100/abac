<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('page.partials.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row mb50 mt30">
            <?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col l6 m6 s12 novedad">
                <div class="novedad-card">
                    <h5 class="ultimas-novedades mb40">Últimas novedades</h5>
                    <div class="row">
                        <div class="col l5">
                            <img src="<?php echo e(asset('img//novedades/'.$n->image)); ?>" class="responsive-img" alt="">
                        </div>
                        <div class="col l7 flex-novedad">
                            
                                <h6 class="mt0 mb0">
                                        <a href="<?php echo e(route('novedades.showNovedad', $n->id)); ?>" class="grayerino">
                                            <?php echo e($n->{'title_'.App::getLocale()}); ?>

                                        </a>
                                </h6>
                            <?php echo str_limit($n->{'text_'.App::getLocale()}, 200); ?>

                            <p class=" mt10">
                                <a href="<?php echo e(route('novedades.showNovedad', $n->id)); ?>" class="rederino">
                                    » Ver más
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <h4 class="center uppercase rederino oblique fw6 mb50">Productos destacados</h4>
            <div class="row">
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col l3 m6 s12 mb50">
                    <div class="product-card">
                        <div class="product-img">
                        <a  href="<?php echo e(route('productos.show', $p->id)); ?>" class="center">
                                <p class="center">
                                    <img src="<?php echo e(asset('img/productos/'.$p->image)); ?>" class="responsive-img">
                                </p>
                            </a>
                        </div>
                        <div class="product-text">
                            <a href="<?php echo e(route('productos.show', $p->id)); ?>" style="display:flex; justify-content:space-between; align-items:center; width:100%;">
                                <div class="product-description grayerino fw6">
                                    VA1 VÁLVULAS AGUJA DE BLOQUEO
                                </div>
                                <div class="product-plus">
                                    <i class="material-icons rederino">add</i>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="experiencia-rubro center">
        <div class="container flex-column-center" style="height:100%;">
            <h6 class="grayerino mb0"> <?php echo e($text->{'title_'.App::getLocale()}); ?> </h6>
            <h4 class="rederino mt10 mb0"><?php echo e($text->{'subtitle_'.App::getLocale()}); ?></h4>
            <p class="grayerino"><?php echo $text->{'text_'.App::getLocale()}; ?></p>
        <a class="waves-effect waves-light btn" href="<?php echo e(route('empresa')); ?>" style="background-color:#eb252d;">CONOCÉ MÁS</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
M.Slider.init(document.querySelector('.slider'), {height: 700});
</script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>