<?php $__env->startSection('body'); ?>
<main>
<div class="container">
    <div class="row">
        <div class="col s12">
            <table class="highlight bordered">
            <thead>
                <td>Imagen</td>
                <td>Titulo</td>
                <td>Orden</td>
                <td class="text-right">Acciones</td>
            </thead>
            <tbody>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

        <td><img class="slider-foto" src="<?php echo e(asset("img/sliders/".$slider->image)); ?>" height="100px"></td>
                    <td><span><?php echo $slider->title_es; ?></span></td>
                    <td><span class="adm-estandar"><?php echo $slider->order; ?></span></td>
                    <td class="text-right">
                        <a href="<?php echo e(route('slider.edit',$slider->id)); ?>"><i class="material-icons">create</i></a>
                        <?php echo Form::open(['class'=>'en-linea', 'route'=>['slider.destroy', $slider->id], 'method' => 'DELETE']); ?>

                            <button type="submit" class="submit-button">
                                <i class="material-icons red-text">cancel</i>
                            </button>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php echo $sliders->render(); ?>

</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>