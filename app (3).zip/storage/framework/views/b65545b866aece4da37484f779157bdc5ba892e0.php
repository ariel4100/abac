    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick-theme.css')); ?>"/>

    <link href="<?php echo e(asset('css/materialize.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilo.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos.css')); ?>?1" rel="stylesheet">
	
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <link rel="shortcut icon" href="<?php echo e(asset('img/contenido/'.$favicon->image)); ?>" type="image/png">
    <link rel="icon" href="<?php echo e(asset('img/contenido/'.$favicon->image)); ?>" type="image/png">