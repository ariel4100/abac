<?php $__env->startSection('content'); ?>
<div class="container">
        <p class="">
            <a href="<?php echo e(route('contacto')); ?>" class="hoverino">
                < Regresar a Contacto
            </a>
        </p>
    
        <?php echo $__env->make('page.partials.title', ['title' => 'Trabaje con Nosotros'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
        <p class="mt30 mb20">
            Complete el siguiente formulario y nos contactaremos a la brevedad
        </p>
    
        <form action="<?php echo e(route('contacto.work')); ?>" method="POST" class="row">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="nombre" type="text" name="nombre" class="validate">
                    <label for="nombre">Nombre</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="apellido" type="text" name="apellido" class="validate">
                    <label for="apellido">Apellido</label>
                </div>
            </div>
            
            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="empresa" type="text" name="empresa" class="validate datepicker">
                    <label for="empresa">Fecha de nacimiento</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="email" type="email" name="email" class="validate">
                    <label for="email">E-Mail</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="empresa" type="text" name="empresa" class="validate">
                    <label for="empresa">Empresa</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="email" type="email" name="email" class="validate">
                    <label for="email">E-Mail</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="empresa" type="text" name="empresa" class="validate">
                    <label for="empresa">Empresa</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="email" type="email" name="email" class="validate">
                    <label for="email">E-Mail</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="empresa" type="text" name="empresa" class="validate">
                    <label for="empresa">Empresa</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="email" type="email" name="email" class="validate">
                    <label for="email">E-Mail</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col l6 s12">
                    <input id="empresa" type="text" name="empresa" class="validate">
                    <label for="empresa">Empresa</label>
                </div>
                <div class="input-field col l6 s12">
                    <input id="email" type="email" name="email" class="validate">
                    <label for="email">E-Mail</label>
                </div>
            </div>

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    M.Datepicker.init(document.querySelector('.datepicker'), {
            firstDay: true, 
            format: 'dd / mm / yyyy',
            i18n: {
                months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
                monthsShort: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Set", "Oct", "Nov", "Dic"],
                weekdays: ["Domingo","Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
                weekdaysShort: ["Dom","Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
                weekdaysAbbrev: ["D","L", "M", "M", "J", "V", "S"],
                cancel:'Cancelar',
                clear:'Limpiar',
                done:'Listo'
            },
            maxDate: new Date(),
            yearRange: [1900, 2019]
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>