<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('page.partials.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row mt30 mb30">
            <div class="col l6">
                <?php echo $__env->make('page.partials.title', ['title' => $empresa[0]->{'title_'.App::getLocale()} ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $empresa[0]->{'text_'.App::getLocale()}; ?>

            </div>
            <div class="col l6">
            <img src="<?php echo e(asset('img/contenido/'.$empresa[0]->image)); ?>" class="responsive-img" alt="<?php echo e($empresa[0]->{'title_'.App::getLocale()}); ?>">
            </div>
        </div>
        <div class="row center">
            <h5 class="rederino"><?php echo e($empresa[1]->{'title_'.App::getLocale()}); ?></h5>
            <?php echo $empresa[1]->{'text_'.App::getLocale()}; ?>

            <div class="container">
                <div class="row mt30 mb10">
                <?php $__currentLoopData = $mercados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col l3 m6 s12 mb20">
                        <img src="<?php echo e(asset('img/contenido/'.$m->image)); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col l6">
                <h5 class="rederino"><?php echo e($empresa[2]->{'title_'.App::getLocale()}); ?></h5>
                <?php echo $empresa[2]->{'text_'.App::getLocale()}; ?>

            </div>
            <div class="col l6">
                <h5 class="rederino"><?php echo e($empresa[3]->{'title_'.App::getLocale()}); ?></h5>
                <?php echo $empresa[3]->{'text_'.App::getLocale()}; ?>

            </div>
        </div>
    </div>
    <div class="experiencia-rubro flex-column-center">
        <h4>Principales Clientes</h4>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
M.Slider.init(document.querySelector('.slider'), {height: 500});
</script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>