<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt50 mb30">
        <div class="col l4">
            <div class="col s12">
                <ul class="tabs">
                    <li class="tab col s6"><a href="#test1">ARGENTINA</a></li>
                    <li class="tab col s6"><a class="active" href="#test2">Mundo</a></li>
                </ul>
            </div>
        </div>
        <div class="col l8 center">
            <div id="test1" class="col s12">Test 1</div>
            <div id="test2" class="col s12">Test 2</div>
        </div>
    </div>
</div>

<div class="row distribuidores">

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    M.Tabs.init(document.querySelector('.tabs'));
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>