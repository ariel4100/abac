<?php $__env->startSection('content'); ?>

<?php echo $__env->make('page.productos.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
    <div class="row mt30 mb50">
        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col l4">
                <div class="producterino">
                    <div class="product-img" style="height: 280px; display:flex; justify-content:center; align-items:center">
                        <a href="<?php echo e(route('familias.show', ['familia' => $f->id])); ?>" style="display:flex; justify-content:center; align-items:center">
                            <img src="<?php echo e(asset('img/familias/'.$f->image)); ?>" alt="<?php echo e($f->{'title_'.App::getLocale()}); ?>" class="responsive-img">
                        </a>
                    </div>
                    <div class="product-description center mt10">
                        <a href="<?php echo e(route('familias.show', ['familia' => $f->id])); ?>" class="rederino fw6">
                            <?php echo e($f->{'title_'.App::getLocale()}); ?>

                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>