

<?php $__env->startSection('body'); ?>
<main>
    <div class="container mb30">
            <div class="row mt30">
                <div class="col s12">
                    <?php echo Form::open(['route'=>'contenido.store', 'method'=>'POST', 'files' => true]); ?>

                    Ingresar la siguiente parte de la ruta: https://www.youtube.com/watch?v=<span class="bold">dQw4w9WgXcQ</span>
                    <div class="row">
                        <div class="input-field col s8">
                            <?php echo Form::label('Ruta'); ?>

                            <?php echo Form::text('ruta',null,['class'=>'validate']); ?>

                        </div>
                        <div class="input-field col s4">
                            <?php echo Form::label('Orden'); ?>

                            <?php echo Form::text('order',null,['class'=>'validate']); ?>

                        </div>
                    </div>
                    <input type="hidden" name="type" value="<?php echo e($tipo); ?>">
                    <input type="hidden" name="section" value="<?php echo e($section); ?>">
                    <div class="row">
                        <div class="input-field col s6">
                            <?php echo Form::label('Titulo Español'); ?>

                            <?php echo Form::text('title_es',null,['class'=>'validate']); ?>

                        </div>
                        <div class="input-field col s6">
                            <?php echo Form::label('Titulo Ingles'); ?>

                            <?php echo Form::text('title_en',null,['class'=>'validate']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <?php echo Form::label('Caption Español'); ?>

                            <?php echo Form::text('text_es',null,['class'=>'validate']); ?>

                        </div>
                        <div class="input-field col s6">
                            <?php echo Form::label('Caption Ingles'); ?>

                            <?php echo Form::text('text_en',null,['class'=>'validate']); ?>

                        </div>
                    </div>

                    <div class="col s12 no-padding">
                        <?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

                    </div>
                <?php echo Form::close(); ?>

                </div>
            </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>