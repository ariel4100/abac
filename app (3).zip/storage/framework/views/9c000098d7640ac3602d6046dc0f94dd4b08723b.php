<nav class="sub-nav">
    <div class="nav-wrapper">
        <ul id="nav-mobile" class="right">
            <li>
                <?php if(Auth::check()): ?>
                    <div class="sub-nav-text" style="display:flex;">
                    <a href="<?php echo e(route('privada.index')); ?>" style="padding-right:5px;">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <a href="<?php echo e(route('logout')); ?>" class="sub-nav-text" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();" style="padding-left:0px;">(salir)</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="uppercase sub-nav-text">Acceso Clientes</a>
                <?php endif; ?>
            </li>
            <li><a href="#" class="uppercase sub-nav-text" style="padding:0">|</a></li>
            <li><a href="<?php echo e(route('novedades')); ?>" class="uppercase sub-nav-text">Novedades</a></li>
            <li><a href="#" class="uppercase sub-nav-text" style="padding:0">|</a></li>
            <li><a href="<?php echo e(route('contacto')); ?>" class="uppercase sub-nav-text">Contacto</a></li>
            <li><a href="#!" class="hide-on-med-and-down" style="height: 64px;"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#!" class="hide-on-med-and-down" style="height: 64px;"><i class="fab fa-youtube"></i></a></li>
            <li>
                <a class='dropdown-trigger btn' href='#' style="background-color:rgb(235, 37, 45);" data-target='dropdown1'><?php echo e(strtoupper(App::getLocale())); ?></a> 
            </li>
        </ul>
    </div>
</nav>
<nav class="nav-primary">
    <div class="nav-wrapper nav-second">
        <a href="<?php echo e(route('index')); ?>" class="brand-logo">
            <img class="responsive-img" src="<?php echo e(asset('img/contenido/'.$header->image)); ?>">
        </a>
        <a href="#!" data-target="mobile-demo" class="sidenav-trigger left" id="sidenavsillo" style="color:black;"><i class="material-icons">menu</i></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li><a href="<?php echo e(route('empresa')); ?>" <?php if(\Request::is('nosotros')): ?> class="activerino" <?php endif; ?>><?php echo e(__('About Us')); ?></a></li>
            <li><a href="<?php echo e(route('productos')); ?>" <?php if(\Request::is('productos*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Products')); ?></a></li>
            <li><a href="<?php echo e(route('descargas')); ?>" <?php if(\Request::is('descargas')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Downloads')); ?></a></li>
            <li><a href="<?php echo e(route('herramientas')); ?>" <?php if(\Request::is('herramientas*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Tools')); ?></a></li>
            <li><a href="<?php echo e(route('calidad')); ?>" <?php if(\Request::is('calidad*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Quality')); ?></a></li>
            <li><a href="<?php echo e(route('videos')); ?>" <?php if(\Request::is('videos')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Videos')); ?></a></li>
            <li><a href="<?php echo e(route('distribuidores')); ?>" <?php if(\Request::is('distribuidores')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Distributors')); ?></a></li>
        </ul>
    </div>
</nav>

<!-- Dropdown Structure -->
<ul id='dropdown1' class='dropdown-content'>
    <li><a href="/setlocale/es">ES</a></li>
    <li><a href="/setlocale/en">EN</a></li>
</ul>   

<ul class="sidenav" id="mobile-demo">
    <li><a href="sass.html">Sass</a></li>
    <li><a href="badges.html">Components</a></li>
    <li><a href="collapsible.html">Javascript</a></li>
    <li><a href="mobile.html">Mobile</a></li>
</ul>

<?php $__env->startPush('scripts'); ?>
<script>
    M.Dropdown.init(document.querySelector('.dropdown-trigger'))
    M.Sidenav.init(document.querySelector('#sidenavsillo'))
    console.log(document.querySelector('#sidenavsillo'))
</script>
<?php $__env->stopPush(); ?>