<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb40 mt30">
        <?php echo $__env->make('page.partials.title', ['title' => 'Novedades'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="row">
        <div class="col l10">
            <div class="row mb30">
                <?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col l6 mb20">
                    <div class="novedad-card" style="padding: 10px 40px;">
                        <div class="row flex-column">
                            <div style="display:flex; justify-content:center; align-items:center">
                                <p class="center">
                                    <img src="<?php echo e(asset('img/novedades/'.$n->image)); ?>" class="responsive-img" alt="">
                                </p>
                            </div>
                            <div class="categoria-novedad">
                                <p class="uppercase mb0" style="width:30%; font-size:0.8rem">
                                    <a href="<?php echo e(route('novedades.showCategory', $n->categoria->id)); ?>" class="grayerino">
                                        <?php echo e($n->categoria->{'title_'.App::getLocale()}); ?>

                                    </a>
                                </p>
                                <div style="width:80%; background-color:#B0B0B0; height:1px; margin-top:14px"></div>
                            </div>
                            <h6 class="mt20 mb0" style="color:#2B2B2B">
                                <a href="<?php echo e(route('novedades.showNovedad', $n->id)); ?>" class="grayerino">
                                    <?php echo e($n->{'title_'.App::getLocale()}); ?>

                                </a>
                            </h6>
                            <span style="margin-top:5px"><?php echo e($n->created_at->diffForHumans()); ?></span>
                            <?php echo $n->{'text_'.App::getLocale()}; ?>

                            <p class="">
                                <a href="<?php echo e(route('novedades.showNovedad', $n->id)); ?>" class="rederino">
                                    » Ver más
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col l2">
            <div class="flex-column">
                <p class="uppercase rederino mb0" style="margin-bottom:5px;">Categorias</p>
                <div class="separatorsillo mb20"></div>
                    <a href="<?php echo e(route('novedades')); ?>" class="categoriaa mb10">» Todas</a>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('novedades.showCategory', $c->id)); ?>" class="categoriaa mb10">» <?php echo e($c->{'title_'.App::getLocale()}); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>