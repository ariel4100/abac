

<?php $__env->startSection('body'); ?>
<main>
	<div class="container">
		<div class="row mb30 mt30">
                <a href="<?php echo e(route('categoria.index')); ?>"><< Volver</a>
			<div class="col s12">
			<?php echo Form::model($categoria,['route'=>['categoria.update', $categoria->id], 'method'=>'PUT', 'files' => true]); ?>

			<div class="row">

				<div class="row mt30">
					<div class="input-field col s5">
						<?php echo Form::label('Titulo Español'); ?>

						<?php echo Form::text('title_es',null,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s5">
						<?php echo Form::label('Titulo Ingles'); ?>

						<?php echo Form::text('title_en',null,['class'=>'validate']); ?>

                    </div>
                    <div class="input-field col s2">
                            <?php echo Form::label('Orden'); ?>

                            <?php echo Form::text('order', null, ['class'=>'validate', 'required']); ?>

                        </div>
				</div>

				<div class="col s12 no-padding">
					<?php echo Form::submit('Editar', ['class'=>'waves-effect waves-light btn right white-text']); ?>

				</div>

			</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>