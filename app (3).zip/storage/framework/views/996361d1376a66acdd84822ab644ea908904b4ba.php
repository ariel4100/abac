<?php $__env->startSection('body'); ?>
<main>
	<div class="container">
		<div class="row mb30">
			<div class="col s12">
			<?php echo Form::open(['route'=>'familia.store', 'method'=>'POST', 'files' => true]); ?>

			<div class="row">

				<div class="row">
					<div class="file-field input-field col s8">
						<div class="btn">
								<span>Imagen</span>
								<?php echo Form::file('image'); ?>

						</div>
						<div class="file-path-wrapper">
								<?php echo Form::text('',null, ['class'=>'file-path validate', 'required']); ?>

						</div>
					</div>

					<div class="input-field col s4">
						<?php echo Form::label('Orden'); ?>

						<?php echo Form::text('order', null, ['class'=>'validate', 'required']); ?>

					</div>
				</div>

				<div class="row">
					<div class="input-field col s6">
						<?php echo Form::label('Titulo Español'); ?>

						<?php echo Form::text('title_es',null,['class'=>'validate']); ?>

					</div>
					<div class="input-field col s6">
						<?php echo Form::label('Titulo Ingles'); ?>

						<?php echo Form::text('title_en',null,['class'=>'validate']); ?>

					</div>
				</div>

				<div class="col s12 no-padding">
					<?php echo Form::submit('Crear', ['class'=>'waves-effect waves-light btn right white-text']); ?>

				</div>

			</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>