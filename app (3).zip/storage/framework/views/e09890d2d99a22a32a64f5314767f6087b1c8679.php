<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="breadcrumbsish mt10" class="categoriaa">
        <a href="<?php echo e(route('novedades')); ?>" class="categoriaa">Novedades</a> | 
        <a href="<?php echo e(route('novedades.showCategory', $novedad->categoria->id)); ?>" class="categoriaa"><?php echo e($novedad->categoria->{'title_'.App::getLocale()}); ?></a> | 
        <a href="<?php echo e(route('novedades.showNovedad', $novedad->id)); ?>" class="categoriaa">
            <?php echo e($novedad->{'title_'.App::getLocale()}); ?>

        </a>
    </div>
    <div class="row mt30 mb70">
        <div class="col l10">
            <div style="display:flex; align-items:center;">
                <p class="uppercase mb0 parte2ytal">
                    <a href="<?php echo e(route('novedades.showCategory', $novedad->categoria->id)); ?>" class="grayerino">
                        <?php echo e($novedad->categoria->{'title_'.App::getLocale()}); ?>

                    </a>
                </p>
                <div class="ya-saquenme-de-aqui" ></div>
            </div>
            <p class="center">
                <img src="<?php echo e(asset('img/novedades/'.$novedad->image)); ?>" class="responsive-img">
            </p>
            <h5 class="rederino"><?php echo e($novedad->{'title_'.App::getLocale()}); ?></h5>
            <p class="grayerino"><?php echo e($novedad->created_at->diffForHumans()); ?></p>
            <div class="grayerino">
                <?php echo $novedad->{'text_'.App::getLocale()}; ?>

            </div>
        </div>
        <div class="col l2">
            <div class="flex-column">
                <p class="uppercase rederino mb0" style="margin-bottom:5px;">Categorias</p>
                <div class="separatorsillo mb20"></div>
                <a href="<?php echo e(route('novedades')); ?>" class="categoriaa mb10">» Todas</a>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('novedades.showCategory', $c->id)); ?>" class="categoriaa">
                        » <?php echo e($c->{'title_'.App::getLocale()}); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>