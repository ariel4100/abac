

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('templates.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('page.partials.title', ['title' =>  __('Login') ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form action="<?php echo e(route('login')); ?>" method="POST" class="row mb50">
            <?php echo csrf_field(); ?>
            <div class="row mt20">
                <div class="input-field col s6">
                    <input id="username" name="username" type="text" class="validate" required>
                <label for="username"><?php echo e(__('Username')); ?></label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                    <input id="password" name="password" type="password" class="validate" required>
                    <label for="password"><?php echo e(__('Password')); ?></label>
                </div>
            </div>
            <button class="btn waves-effect waves-light" type="submit" name="action" style="background-color: #E1131B;"><?php echo e(__('Login')); ?>

                <i class="material-icons right">send</i>
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>