<?php $__env->startSection('product'); ?>
    <div class="row productos mb50">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col l4">
            <div class="producterino">
                <div class="product-img" style="max-height: 250px; display:flex; justify-content:center; align-items:center">
                    <a href="<?php echo e(route('productos.show', ['producto' => $p->id])); ?>" style="display:flex; justify-content:center; align-items:center">
                        <img src="<?php echo e(asset('img/productos/'.$p->image)); ?>" alt="<?php echo e($p->{'title_'.App::getLocale()}); ?>" class="responsive-img">
                    </a>
                </div>
                <div class="product-description center mt10">
                    <a href="<?php echo e(route('familias.show', ['familia' => $p->id])); ?>" class="rederino fw6">
                        <?php echo e($p->{'title_'.App::getLocale()}); ?>

                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.productos.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>