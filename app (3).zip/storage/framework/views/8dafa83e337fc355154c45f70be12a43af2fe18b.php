<?php $__env->startSection('body'); ?>
<main>
<div class="container">
    <div class="row">
        <div class="col s12">
            <table class="highlight bordered">
            <thead>
                <td>Imagen</td>
                <td>Orden</td>
                <td class="text-right">Acciones</td>
            </thead>
            <tbody>
            <?php $__currentLoopData = $contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><img src="<?php echo e(asset('/img/contenido/'.$c->image)); ?>" alt="<?php echo e($c->title_es); ?>" style="height:100px" class="responsive-img"></td>
                    <td><span class="adm-estandar"><?php echo $c->order; ?></span></td>
                    <td class="text-right">
                        <a href="<?php echo e(route('contenido.edit', [$section, $c->id])); ?>"><i class="material-icons">create</i></a>
                        <?php if($c->eliminable): ?>
                        <?php echo Form::open(['class'=>'en-linea', 'route'=>['contenido.destroy', $c->id], 'method' => 'DELETE']); ?>

                            <button type="submit" class="submit-button">
                                <i class="material-icons red-text">cancel</i>
                            </button>
                        <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>