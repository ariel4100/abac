<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<!-- Materialize Core JavaScript -->
<script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>

<!-- Core JS -->
<script src="<?php echo e(asset('js/admin.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
