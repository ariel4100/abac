<nav class="sub-nav">
    <div class="nav-wrapper">
        <ul id="nav-mobile" class="right">
            <li>
                <?php if(Auth::check()): ?>
                    <div class="sub-nav-text" style="display:flex;">
                    <a href="<?php echo e(route('privada.index')); ?>" style="padding-right:5px;">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <a href="<?php echo e(route('logout')); ?>" class="sub-nav-text" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();" style="padding-left:0px;">(salir)</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="uppercase sub-nav-text">Acceso Clientes</a>
                <?php endif; ?>
            </li>
            <li><a href="#" class="uppercase sub-nav-text" style="padding:0">|</a></li>
            <li><a href="<?php echo e(route('novedades')); ?>" class="uppercase sub-nav-text">Novedades</a></li>
            <li><a href="#" class="uppercase sub-nav-text" style="padding:0">|</a></li>
            <li><a href="<?php echo e(route('contacto')); ?>" class="uppercase sub-nav-text" style="margin-right: 0; padding-right: 5px">Contacto</a></li>
            <li><a href="https://www.facebook.com/pages/category/Industrial-Company/ABAC-SRL-165035077562951/" target="_blank" class="hide-on-med-and-down" style="height: 64px;"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCAUMO65Z8Tcg-bj-7JXOmLw" class="hide-on-med-and-down" target="_blank" style="height: 64px;"><i class="fab fa-youtube"></i></a></li>
             <li><a href="#!" class="hide-on-med-and-down" style="height: 64px;"><i class="fas fa-search"></i></a></li>
            <li>
                <a class='dropdown-trigger btn' href='#' style="background-color:rgb(235, 37, 45); margin: 0" data-target='dropdown1'><?php echo e(strtoupper(App::getLocale())); ?></a> 
            </li>
        </ul>
    </div>
</nav>
<nav class="nav-primary">
    <div class="nav-wrapper nav-second">
        <a href="<?php echo e(route('index')); ?>" class="brand-logo">
            <img class="responsive-img" src="<?php echo e(asset('img/contenido/'.$header->image)); ?>">
        </a>
        <a href="#!" data-target="mobile-demo" class="sidenav-trigger left" id="sidenavsillo" style="color:black;"><i class="material-icons">menu</i></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li><a href="<?php echo e(route('empresa')); ?>" <?php if(\Request::is('nosotros')): ?> class="activerino" <?php endif; ?>><?php echo e(__('About Us')); ?></a></li>
            <li><a class="dropdown-trigger" style="position: relative; padding-right: 30px;" href="<?php echo e(route('productos')); ?>" data-target="productos" <?php if(\Request::is('productos*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Products')); ?><i class="material-icons right" style="height: 50px;top: -10px;right: 0px;    position: absolute;">arrow_drop_down</i></a></li>
            <li><a href="<?php echo e(route('descargas')); ?>" <?php if(\Request::is('descargas')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Downloads')); ?></a></li>
            <li><a class="dropdown-trigger" style="position: relative; padding-right: 30px;" href="<?php echo e(route('productos')); ?>" data-target="herramientas" <?php if(\Request::is('herramientas*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Tools')); ?><i class="material-icons right" style="height: 50px;top: -10px;right: 0px;    position: absolute;">arrow_drop_down</i></a></li>
            <li><a href="<?php echo e(route('calidad')); ?>" <?php if(\Request::is('calidad*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Quality')); ?></a></li>
            <li><a href="<?php echo e(route('videos')); ?>" <?php if(\Request::is('videos')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Videos')); ?></a></li>
            <li><a href="<?php echo e(route('distribuidores')); ?>" <?php if(\Request::is('distribuidores')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Distributors')); ?></a></li>
        </ul>
    </div>
</nav>
<?php ($items = \App\Familia::orderBy('order')->limit(8)->get()); ?>
<?php ($items1 = \App\Contenido::seccionTipo('herramientas', 'texto')->orderBy('order')->get()); ?>
<!-- Dropdown Structure -->
<ul id="productos" class="dropdown-content">
    <li><a href="<?php echo e(route('productos')); ?>">Todos</a></li>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('familias.show', ['familia' => $item->id])); ?>"><?php echo e($item->title_es); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<ul id="herramientas" class="dropdown-content">
    <li><a href="<?php echo e(route('herramientas')); ?>">Todos</a></li>
    <?php $__currentLoopData = $items1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route($h->ruta)); ?>"><?php echo e($h->{'title_'.App::getLocale()}); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<!-- Dropdown Structure -->
<ul id='dropdown1' class='dropdown-content'>
    <li><a href="/abac/setlocale/es" style="color:#eb262d;">ES</a></li>
    <li><a href="/abac/setlocale/en" style="color:#eb262d;">EN</a></li>
</ul>   

<ul class="sidenav" id="mobile-demo">
    <li><a href="<?php echo e(route('empresa')); ?>" <?php if(\Request::is('nosotros')): ?> class="activerino" <?php endif; ?>><?php echo e(__('About Us')); ?></a></li>
            <li><a href="<?php echo e(route('productos')); ?>" <?php if(\Request::is('productos*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Products')); ?></a></li>
            <li><a href="<?php echo e(route('descargas')); ?>" <?php if(\Request::is('descargas')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Downloads')); ?></a></li>
            <li><a href="<?php echo e(route('herramientas')); ?>" <?php if(\Request::is('herramientas*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Tools')); ?></a></li>
            <li><a href="<?php echo e(route('calidad')); ?>" <?php if(\Request::is('calidad*')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Quality')); ?></a></li>
            <li><a href="<?php echo e(route('videos')); ?>" <?php if(\Request::is('videos')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Videos')); ?></a></li>
            <li><a href="<?php echo e(route('distribuidores')); ?>" <?php if(\Request::is('distribuidores')): ?> class="activerino" <?php endif; ?>><?php echo e(__('Distributors')); ?></a></li>
</ul>

<?php $__env->startPush('scripts'); ?>
<script>
    M.Sidenav.init(document.querySelector('#sidenavsillo'))
    M.Dropdown.init(document.querySelector('.dropdown-trigger'))
</script>
<?php $__env->stopPush(); ?>