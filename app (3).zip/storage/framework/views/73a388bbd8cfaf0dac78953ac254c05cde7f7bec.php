<?php if(session('success')): ?>
<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>