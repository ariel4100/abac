

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt30 mb10">
        <div class="col l4 m4 s12 right-border-download">
            <div class="img-wrapper flex-column-center">
                <img src="<?php echo e(asset('img/contenido/'.$headerLogos[0]->image)); ?>" class="responsive-img" alt="">
                <img src="<?php echo e(asset('img/contenido/'.$headerLogos[1]->image)); ?>" class="responsive-img" alt="">
            </div>
        </div>
        <div class="col l4 m4 s12 right-border-download">
            <div class="img-wrapper flex-column-center" style="margin-top:-10px; max-height:138px">
                <img src="<?php echo e(asset('img/contenido/'.$headerLogos[2]->image)); ?>" class="responsive-img" alt="">
            </div>
        </div>
        <div class="col l4 m4 s12 " style="height:100%;">
            <div class="img-wrapper flex-column-center imagensilla">
                <img src="<?php echo e(asset('img/contenido/'.$headerLogos[3]->image)); ?>" class="responsive-img" alt="">
            </div>
        </div>
    </div>
    <div class="three-download-logo-separator mb50"></div>
    <div class="row mb30">
        <h4 class="rederino mb20">Catalogos</h4>
        <?php $__currentLoopData = $catalogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col l3 mb20" style="margin-left:-10px; margin-right:10px;">
            <div class="descarga flex-column-center" style="border:1px #9a9a9a solid">
                <img src="<?php echo e(asset('img/contenido/'.$cat->image)); ?>" alt="<?php echo e($cat->{'title_'.App::getLocale()}); ?>" class="responsive-img">
            </div>
            <p class="mt10 mb10" style="color:#666666;">
                <?php echo e($cat->{'title_'.App::getLocale()}); ?>

            </p>
            <div class="light-separator"></div>
            <div class="download-actions">
                <div class="download-cta">
                    <a href="<?php echo e(route('downloadFile', ['file' => $cat->ficha])); ?>" style="color:white">
                        <i class="material-icons">file_download</i>
                    </a>
                </div>
                <div class="download-see">
                    <a href="<?php echo e(asset('files/contenido/'.$cat->ficha)); ?>" style="color:white" target="_blank">
                        <i class="material-icons">remove_red_eye</i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row mb30">
        <h4 class="rederino mb20">Instrucciones de Montaje / Mantenimiento</h4>
        <?php $__currentLoopData = $mm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col l3 mb20" style="margin-left:-10px; margin-right:10px;">
            <div class="descarga flex-column-center" style="border:1px #9a9a9a solid">
                <img src="<?php echo e(asset('img/contenido/'.$m->image)); ?>" alt="<?php echo e($m->{'title_'.App::getLocale()}); ?>" class="responsive-img">
            </div>
            <p class="mt10 mb10" style="color:#666666;">
                <?php echo e($m->{'title_'.App::getLocale()}); ?>

            </p>
            <div class="light-separator"></div>
            <div class="download-actions">
                <div class="download-cta">
                    <a href="<?php echo e(route('downloadFile', ['file' => $m->ficha])); ?>" style="color:white">
                        <i class="material-icons">file_download</i>
                    </a>
                </div>
                <div class="download-see">
                    <a href="<?php echo e(asset('files/contenido/'.$m->ficha)); ?>" style="color:white" target="_blank">
                        <i class="material-icons">remove_red_eye</i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>