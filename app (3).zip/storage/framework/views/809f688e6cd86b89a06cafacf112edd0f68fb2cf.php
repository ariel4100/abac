

<?php $__env->startSection('content'); ?>
<div class="container">
    <p class="">
        <a href="<?php echo e(route('contacto')); ?>" class="hoverino">
            < Regresar a Contacto
        </a>
    </p>

    <?php echo $__env->make('page.partials.title', ['title' => 'Contacto Personalizado'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row mb50">
        <?php $__currentLoopData = $personalizado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col l4 m6 s12 mt30 mb10">
            <div class="row">
                <div class="col s5">
                    <img src="<?php echo e(asset('img/contenido/'.$p->image)); ?>" alt="<?php echo e($p->{'title_'.App::getLocale()}); ?>">
                </div>
                <div class="col s7 personalized-paragraph" style="color:#4B4B4B;">
                    <h5 class="mt0" style="color:#4B4B4B;"><?php echo e($p->{'title_'.App::getLocale()}); ?></h5>
                    <h6 class="mt0" style="color:#E40A07;"><?php echo e($p->{'subtitle_'.App::getLocale()}); ?></h6>
                    <?php echo $p->{'text_'.App::getLocale()}; ?>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>