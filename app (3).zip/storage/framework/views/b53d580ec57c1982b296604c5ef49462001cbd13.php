    <ul class="collapsible">
        <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php if(isset($productos)): ?> <?php if($productos->first()->familia->id === $f->id): ?> active <?php endif; ?> <?php endif; ?>">
                <div class="collapsible-header" style="display:flex; justify-content:space-between; align-items:center;">
                    <a href="<?php echo e(route('familias.show', $f->id)); ?>" class="hoverino <?php if(isset($productos)): ?> <?php if($productos->first()->familia->id === $f->id): ?> current <?php endif; ?> <?php endif; ?>">
                        <?php echo e($f->{'title_'.App::getLocale()}); ?>

                    </a>
                    <i class="material-icons mb0 mt0 rotate">keyboard_arrow_right</i>
                </div>
                <div class="collapsible-body">
                    <ul>
                        <?php $__currentLoopData = $f->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('productos.show', $p->id)); ?>" class="botonera-sumsum <?php if(isset($producto)): ?> <?php if($producto->id === $p->id): ?> current <?php endif; ?> <?php endif; ?>">
                                <?php echo e($p->{'title_'.App::getLocale()}); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php $__env->startPush('scripts'); ?>
        <script>
            M.Collapsible.init(document.querySelector('.collapsible'))
        </script>
    <?php $__env->stopPush(); ?>
