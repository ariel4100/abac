<script src="<?php echo e(asset('js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/slick.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/materialize.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/abac.js')); ?>" type="text/javascript"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>