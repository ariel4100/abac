

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="video-text mb20" style="display:flex;">
        <?php echo $__env->make('page.partials.title', ['title' => 'Videos'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="row">
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col l4 m6 s12">
            <div class="card">
                <iframe class="responsive-video" src="https://www.youtube.com/embed/<?php echo e($v->ruta); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <div class="video-content">
                    <h6 class="title fw6" style="color:#4b4b4b; height: 40px">
                        <?php echo e($v->{'title_'.App::getLocale()}); ?>

                    </h6>
                    <p class="caption" style="height:80px; color:#4b4b4b;">
                        <?php echo e($v->{'text_'.App::getLocale()}); ?>

                    </p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>