

<?php $__env->startSection('body'); ?>
<main>
    <div class="container mb30">
            <div class="row mb50">
                <div class="col s12">
                    <?php echo Form::open(['route'=>'novedad.store', 'method'=>'POST', 'files' => true]); ?>

                    <div class="row">
                        <div class="file-field input-field col s8">
                            <div class="btn">
                                <span>Imagen</span>
                                <?php echo Form::file('image'); ?>

                            </div>
                            <div class="file-path-wrapper">
                                <?php echo Form::text('', null, ['class'=>'file-path validate']); ?>

                            </div>
                        </div>
                        <div class="input-field col s4">
                            <?php echo Form::label('Orden'); ?>

                            <?php echo Form::text('order',null,['class'=>'validate']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <?php echo Form::label('Titulo Español'); ?>

                            <?php echo Form::text('title_es',null,['class'=>'validate']); ?>

                        </div>
                        <div class="input-field col s6">
                            <?php echo Form::label('Titulo Ingles'); ?>

                            <?php echo Form::text('title_en',null,['class'=>'validate']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <label class="col s12" for="texto_es">Texto Español</label>
                        <div class="input-field col s12">
                            <?php echo Form::textarea('text_es',null,['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <label class="col s12" for="texto_en">Texto Ingles</label>
                        <div class="input-field col s12">
                            <?php echo Form::textarea('text_en',null,['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s8">
                            <select name="categoria_id" id="categorias">
                                <option value="" disabled selected>Elija una categoria</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($f->id); ?>"><?php echo e($f->title_es); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label>Categoria</label>
                        </div>
                        <p style="display:flex; justify-content:center; align-items:center;" class="col s4">
                            <label>
                              <input type="checkbox" name="destacado" />
                              <span>Novedad destacada?</span>
                            </label>
                          </p>
                    </div>
                        

                      <?php $__env->startPush('scripts'); ?>
                    <script>
                        M.FormSelect.init(document.querySelector('#categorias'));
                    </script>
                      <?php $__env->stopPush(); ?>

                    <div class="col s12 no-padding">
                        <?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

                    </div>
                <?php echo Form::close(); ?>

                </div>
            </div>
    </div>
</main>

    <script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('text_es');
        CKEDITOR.replace('text_en');
        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>