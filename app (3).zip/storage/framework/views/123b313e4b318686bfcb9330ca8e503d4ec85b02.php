<?php $__env->startSection('product'); ?>
    <div class="row productos mb50">
        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <a class="product-item col s12 m6 l4"  href="<?php echo e(route('productos.show', ['producto' => $p->id])); ?>">
                <div class="" style="border: 1px solid #dddddd;  ">
                    <div class="product-image" style="border-bottom: 0px solid #dddddd;">
                        <img src="<?php echo e(asset('img/productos/'.$p->image)); ?>" alt="<?php echo e($p->{'title_'.App::getLocale()}); ?>" class="responsive-img" style="height: 200px;">
                        <div class="product-overlay">
                            <div class="icon">
                                <i class="material-icons">add</i>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="display:flex; justify-content:center; align-items:center; width:100%; padding: 5%">
                    <div class="product-description rederino center fw6">
                        <?php echo e(str_limit($p->{'title_'.App::getLocale()}, 25)); ?>

                    </div>
                </div>
            </a>
            <!--
        <div class="col l4">
            <div class="producterino">
                <div class="product-img" style="max-height: 250px; display:flex; justify-content:center; align-items:center">
                    <a href="<?php echo e(route('productos.show', ['producto' => $p->id])); ?>" style="display:flex; justify-content:center; align-items:center">
                        <img src="<?php echo e(asset('img/productos/'.$p->image)); ?>" alt="<?php echo e($p->{'title_'.App::getLocale()}); ?>" class="responsive-img">
                    </a>
                </div>
                <div class="product-description center mt10">
                    <a href="<?php echo e(route('familias.show', ['familia' => $p->id])); ?>" class="rederino fw6">
                        <?php echo e($p->{'title_'.App::getLocale()}); ?>

                    </a>
                </div>
            </div>
        </div>--->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No se encontraron productos para <?php echo e($familia->{'title_'.App::getLocale()}); ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.productos.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>