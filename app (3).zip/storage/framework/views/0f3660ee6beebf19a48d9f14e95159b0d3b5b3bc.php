    <div class="flex">
        <div class="title">
            <h4 class="rederino"><?php echo e($title); ?></h4>
            <div class="bordersillo"></div>
        </div>
    </div>