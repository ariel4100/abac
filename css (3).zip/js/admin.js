M.AutoInit();
