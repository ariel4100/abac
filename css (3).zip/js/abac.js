  M.AutoInit();
